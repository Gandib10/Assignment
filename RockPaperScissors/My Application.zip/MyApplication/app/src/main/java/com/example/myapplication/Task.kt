package com.example.myapplication

data class Task(
    val name: String,
    var isCompleted: Boolean
)
